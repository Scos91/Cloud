import subprocess
import time
import logging
import datetime

#config
CONTAINER_NAME = "web"
PROCESS_THRESHOLD = 300 #max processes for container 'web'
CHECK_INTERVAL = 5 #seconds
LOG_FILE = "frkBombDef.log"

#logging
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

def get_process_count():
    try:
        result = subprocess.run(
            ["sudo", "docker", "exec", CONTAINER_NAME, "sh", "-c", "ps -e --no-headers | wc -l"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=3
        )
        return int(result.stdout.strip())
    except subprocess.TimeoutExpired:
        logging.warning(f"Container '{CONTAINER_NAME}' is unresponsive. Triggering mitigation.")
        print(f"[!] Timeout: container '{CONTAINER_NAME}' is unresponsive.")
        stop_container()
        return -1
    except Exception as e:
        logging.error(f"Failed to get process count: {e}")
        return -1
    
def stop_container():
    try:
        subprocess.run(["sudo", "docker", "stop", CONTAINER_NAME], check=True)
        logging.warning(f"Stopped container '{CONTAINER_NAME}' due to excessive processes.")
        print(f"[MITIGATION] Stopped container '{CONTAINER_NAME}'")
        time.sleep(10)
        for i in range(10, 0, -1):
            print(f"[INFO] Restarting container in {i} seconds...")
            time.sleep(1)
        subprocess.run(["sudo", "docker", "start", CONTAINER_NAME], check=True)
        logging.warning(f"Restarted container '{CONTAINER_NAME}'.")
        print(f"[MITIGATION] Restarted container '{CONTAINER_NAME}'.")
    except Exception as e:
        logging.error(f"Failed to stop/ restart container '{CONTAINER_NAME}': {e}")
        print(f"[ERROR] Failed to stop/ restart container '{CONTAINER_NAME}': {e}")

def main():
    print(f"[+] Fork Bomb Defense started for container: {CONTAINER_NAME}")
    try:
        while True:
            count = get_process_count()
            timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            if count >= 0:
                print(f"[{timestamp}] Process count in container '{CONTAINER_NAME}': {count}")
            if count > PROCESS_THRESHOLD:
                logging.warning(f"Detected fork bomb behavior! Process count: {count}")
                print(f"[!] Detected fork bomb in '{CONTAINER_NAME}' with {count} processes.")
                stop_container()
                break #optional
            time.sleep(CHECK_INTERVAL)
    except KeyboardInterrupt:
        print("[INFO] Exiting Script... Goodbye!")
        
if __name__ == "__main__":
    main()