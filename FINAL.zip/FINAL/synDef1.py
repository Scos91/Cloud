import subprocess
import time
import logging
import sys
import os
from collections import defaultdict
import datetime

#defaults
CHECK_INTERVAL = 5
THRESHOLD_PER_IP = 5
THRESHOLD_GLOBAL = 20
PORT = 80
BLOCKED_IPS_FILE = "syn_blocked_ips.txt"
LOG_FILE = "synDefense.log"

#handle command-line arguments if provided
if len(sys.argv) >= 2:
    CHECK_INTERVAL = int(sys.argv[1])
if len(sys.argv) >= 3:
    THRESHOLD_PER_IP = int(sys.argv[2])
if len(sys.argv) >= 4:
    THRESHOLD_GLOBAL = int(sys.argv[3])
if len(sys.argv) >= 5:
    PORT = int(sys.argv[4])

logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

BLOCKED_IPS = set()

def load_blocked_ips():
    if os.path.exists(BLOCKED_IPS_FILE):
        with open(BLOCKED_IPS_FILE, 'r') as f:
            for line in f:
                BLOCKED_IPS.add(line.strip())

def save_blocked_ip(ip):
    if ip not in BLOCKED_IPS:
        with open(BLOCKED_IPS_FILE, 'a') as f:
            f.write(ip + '\n')
        BLOCKED_IPS.add(ip)

# def remove_blocked_ip(ip):
#     BLOCKED_IPS.discard(ip)
#     if os.path.exists(BLOCKED_IPS_FILE):
#         with open(BLOCKED_IPS_FILE, 'r') as f:
#             lines = f.readlines()
#         with open(BLOCKED_IPS_FILE, 'w') as f:
#             for line in lines:
#                 if line.strip() != ip:
#                     f.write(line)

def parse_syn_recv():
    result = subprocess.run(["ss", "-ant"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
    lines = result.stdout.splitlines()
    syn_lines = [line for line in lines if "SYN-RECV" in line and f":{PORT}" in line]
    ip_counts = defaultdict(int)
    for line in syn_lines:
        parts = line.split()
        if len(parts) >= 5:
            ip = parts[4].split(':')[0]
            ip_counts[ip] += 1
    return ip_counts

def block_ip(ip):
    if ip not in BLOCKED_IPS:
        subprocess.run(["iptables", "-A", "INPUT", "-s", ip, "-j", "DROP"])
        # BLOCKED_IPS.add(ip)
        save_blocked_ip(ip)
        logging.warning(f"Blocked IP: {ip}")

def main():
    load_blocked_ips()
    print(f"[+] SYN Defense started. Port {PORT}, Interval {CHECK_INTERVAL}s, Per-IP Threshold: {THRESHOLD_PER_IP}, Global Threshold: {THRESHOLD_GLOBAL}")
    while True:
        ip_counts = parse_syn_recv()
        total_syns = sum(ip_counts.values())
        print(f"[{datetime.datetime.now()}] Total SYN-RECV: {total_syns}")

        if total_syns > THRESHOLD_GLOBAL:
            if ip_counts:
                top_ip = max(ip_counts, key=ip_counts.get)
                print(f"[!] Blocking top IP due to global threshold: {top_ip}")
                block_ip(top_ip)
            time.sleep(CHECK_INTERVAL)
            continue

        for ip, count in ip_counts.items():
            if count > THRESHOLD_PER_IP:
                print(f"[!] {ip} has {count} SYN-RECVs")
                block_ip(ip)

        time.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    main()