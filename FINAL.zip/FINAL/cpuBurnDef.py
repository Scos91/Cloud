import psutil
import time
import datetime
import logging
import os
import signal

#config
CPU_THRESHOLD = 80.0 #in %
SAMPLE_INTERVAL = 5 #seconds
MITIGATION_ENABLED = True
LOG_FILE = "cpuBurnDef.log"
TOP_N_PROCESSES = 5 #number of top processes to investigate
MITIGATE_BY_NAME = "python3" #kill only py3 pids

#logging
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

def log_top_processes():
    #prime CPU stats
    for proc in psutil.process_iter():
        try:
            proc.cpu_percent(None)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    time.sleep(1)

    #measure after 1 sec
    process_stats = []
    for proc in psutil.process_iter(['pid', 'name']):
        try:
            cpu = proc.cpu_percent(None)
            process_stats.append((proc.pid, proc.name(), cpu))
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    process_stats.sort(key=lambda x: x[2], reverse=True)
    return process_stats[:TOP_N_PROCESSES]

    # processes = sorted(psutil.process_iter(['pid', 'name', 'cpu_percent']), key=lambda p: p.info['cpu_percent'], reverse=True)
    # top_entries = []
    # for proc in processes[:TOP_N_PROCESSES]:
    #     try:
    #         top_entries.append(f"PID {proc.info['pid']}: {proc.info['name']} - {proc.info['cpu_percent']}% CPU")
    #     except (psutil.NoSuchProcess, psutil.AccessDenied):
    #         continue
    # return top_entries

def kill_process(pid):
    try:
        os.kill(pid, signal.SIGTERM)
        logging.warning(f"Killed high CPU process with PID {pid}")
        print(f"[!] Killed process PID {pid}.")
    except Exception as e:
        logging.error(f"Failed to kill PID {pid}: {e}")
        print(f"[!] Failed to kill PID {pid}: {e}")

def main():
    print(f"[+] CPU Defense started. Threshold: {CPU_THRESHOLD}%")
    try:
        while True:
            cpu = psutil.cpu_percent(interval=1)
            print(f"[{datetime.datetime.now()}] Current CPU usage: {cpu}%")
            if cpu > CPU_THRESHOLD:
                print("[!] High CPU usage detected! Analyzing top Processes...")
                # log_entries = log_top_processes()
                logging.info(f"High CPU usage detected: {cpu}%")

                top_entries = log_top_processes()
                for pid, name, usage in top_entries:
                    log_entry = f"PID {pid}: {name} - {usage:.2f}% CPU"
                    logging.info(log_entry)
                    print(" ", log_entry)

                    if MITIGATION_ENABLED and pid != os.getpid() and name == MITIGATE_BY_NAME:
                        kill_process(pid)
            # for entry in log_entries:
            #     logging.info(f"   {entry}")
            #     print(f"   {entry}")

            # if MITIGATION_ENABLED:
            #     for entry in log_entries:
            #         try:
            #             pid = int(entry.split()[1])
            #             kill_process(pid)
            #         except Exception:
            #             continue
            time.sleep(SAMPLE_INTERVAL)
    except KeyboardInterrupt:
        print("[INFO] Exiting Script... Goodbye!")

if __name__ == "__main__":
    main()