import sys
import subprocess
import threading
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QLabel,
    QPushButton, QLineEdit, QTextEdit, QFormLayout, QMessageBox, QHBoxLayout, QDialog, QRadioButton, QButtonGroup, QListWidget
)
from PyQt5.QtCore import QTimer, Qt, pyqtSignal, QObject
import psutil
import datetime
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import os
import signal

LOG_FILES = [
    "synDefense.log",
    "cpuBurnDef.log",
    "httpFloodDef.log",
    "frkBombDef.log"
]

class QTextEmitter(QObject):
    text_output = pyqtSignal(str)
    fork_output = pyqtSignal(str)
    cpu_output = pyqtSignal(str)

class MetricsGraph(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("System Metrics Graph")
        self.layout = QVBoxLayout()
        self.canvas = FigureCanvas(plt.Figure())
        self.ax = self.canvas.figure.add_subplot(111)
        self.cpu_data = []
        self.mem_data = []
        self.timestamps = []
        self.layout.addWidget(self.canvas)
        self.setLayout(self.layout)

        self.timer = QTimer()
        self.timer.timeout.connect(self.update_plot)
        self.timer.start(2000)

    def update_plot(self):
        cpu = psutil.cpu_percent()
        mem = psutil.virtual_memory().percent
        now = datetime.datetime.now().strftime("%H:%M:%S")

        self.cpu_data.append(cpu)
        self.mem_data.append(mem)
        self.timestamps.append(now)
        self.cpu_data = self.cpu_data[-20:]
        self.mem_data = self.mem_data[-20:]
        self.timestamps = self.timestamps[-20:]

        self.ax.clear()
        self.ax.plot(self.timestamps, self.cpu_data, label="CPU%")
        self.ax.plot(self.timestamps, self.mem_data, label="Memory%")
        self.ax.legend()
        self.ax.set_title("System Metrics Over Time")
        self.ax.set_xticks(range(len(self.timestamps)))
        self.ax.set_xticklabels(self.timestamps, rotation=45, ha='right')
        self.canvas.draw()

class DefenseGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Defense GUI Console")
        self.setGeometry(100, 100, 800, 600)
        self.emitter = QTextEmitter()
        self.emitter.text_output.connect(self.append_output)
        self.emitter.fork_output.connect(self.append_fork_output)
        self.emitter.cpu_output.connect(self.append_cpu_output)

        main_layout = QVBoxLayout()
        self.output = QTextEdit()
        self.output.setReadOnly(True)
        main_layout.addWidget(QLabel("Defense Console Log:"))
        main_layout.addWidget(self.output)

        button_row = QHBoxLayout()
        for name in ["SYN Monitor", "CPU Monitor", "HTTP Monitor", "Fork Bomb Monitor"]:
            btn = QPushButton(name)
            btn.clicked.connect(self.create_popup(name))
            button_row.addWidget(btn)
        main_layout.addLayout(button_row)

        graph_button = QPushButton("Show Graph - System Metrics")
        graph_button.clicked.connect(self.toggle_graph)
        main_layout.addWidget(graph_button, alignment=Qt.AlignCenter)

        widget = QWidget()
        widget.setLayout(main_layout)
        self.setCentralWidget(widget)

        self.metric_window = None
        self.syn_proc = None
        self.cpu_proc = None
        self.http_proc = None
        self.fork_proc = None

        self.log_timer = QTimer()
        self.log_timer.timeout.connect(self.update_logs)
        self.log_timer.start(3000)

    def create_popup(self, name):
        def launcher():
            dialog = QDialog()
            dialog.setWindowTitle(name)
            layout = QVBoxLayout()

            if name == "SYN Monitor":
                form = QFormLayout()
                self.syn_interval = QLineEdit("5")
                self.syn_per_ip = QLineEdit("3")
                self.syn_global = QLineEdit("5")
                form.addRow("Check Interval (s):", self.syn_interval)
                form.addRow("Per-IP Threshold:", self.syn_per_ip)
                form.addRow("Global Threshold:", self.syn_global)
                layout.addLayout(form)

                self.start_button = QPushButton("Start SYN Defense")
                self.stop_button = QPushButton("Stop SYN Defense")
                self.stop_button.setEnabled(False)
                layout.addWidget(self.start_button)
                layout.addWidget(self.stop_button)

                self.start_button.clicked.connect(self.launch_syn_defense)
                self.stop_button.clicked.connect(self.stop_syn_defense)

                self.blocked_list = QListWidget()
                layout.addWidget(QLabel("Blocked IPs:"))
                layout.addWidget(self.blocked_list)
                self.load_blocked_ips()

                self.blocked_ip_timer = QTimer()
                self.blocked_ip_timer.timeout.connect(self.load_blocked_ips)
                self.blocked_ip_timer.start(3000)
                dialog.finished.connect(lambda _: self.blocked_ip_timer.stop())

                unblock = QPushButton("Unblock Selected IP")
                unblock.clicked.connect(self.unblock_ip)
                layout.addWidget(unblock)

            elif name == "CPU Monitor":
                layout.addWidget(QLabel("CPU usage monitor will detect and kill high-usage python3 processes."))

                self.cpu_start_button = QPushButton("Start CPU Monitor")
                self.cpu_stop_button = QPushButton("Stop CPU Monitor")
                self.cpu_stop_button.setEnabled(False)

                layout.addWidget(self.cpu_start_button)
                layout.addWidget(self.cpu_stop_button)

                self.cpu_alert_output = QTextEdit()
                self.cpu_alert_output.setReadOnly(True)

                layout.addWidget(QLabel("CPU Monitor Alerts:"))
                layout.addWidget(self.cpu_alert_output)

                self.cpu_start_button.clicked.connect(self.launch_cpu_monitor)
                self.cpu_stop_button.clicked.connect(self.stop_cpu_monitor)

            elif name == "HTTP Monitor":
                form = QFormLayout()
                self.http_threshold = QLineEdit("100")
                self.http_interval = QLineEdit("10")
                form.addRow("Request Threshold:", self.http_threshold)
                form.addRow("Interval (s):", self.http_interval)
                layout.addLayout(form)

                self.http_start_button = QPushButton("Start HTTP Monitor")
                self.http_stop_button = QPushButton("Stop HTTP Monitor")
                self.http_stop_button.setEnabled(False)

                layout.addWidget(self.http_start_button)
                layout.addWidget(self.http_stop_button)

                self.http_blocked_list = QListWidget()
                layout.addWidget(QLabel("Blocked IPs:"))
                layout.addWidget(self.http_blocked_list)
                self.load_http_blocked_ips()

                self.http_blocked_ip_timer = QTimer()
                self.http_blocked_ip_timer.timeout.connect(self.load_http_blocked_ips)
                self.http_blocked_ip_timer.start(3000)
                dialog.finished.connect(lambda _: self.http_blocked_ip_timer.stop())

                http_unblock = QPushButton("Unblock Selected IP")
                http_unblock.clicked.connect(self.unblock_http_ip)
                layout.addWidget(http_unblock)

                self.http_start_button.clicked.connect(self.launch_http_monitor)
                self.http_stop_button.clicked.connect(self.stop_http_monitor)

            elif name == "Fork Bomb Monitor":
                layout.addWidget(QLabel("Monitors the 'web' container for fork bomb behavior."))

                self.fork_start_button = QPushButton("Start Fork Bomb Monitor")
                self.fork_stop_button = QPushButton("Stop Fork Bomb Monitor")
                self.fork_stop_button.setEnabled(False)

                layout.addWidget(self.fork_start_button)
                layout.addWidget(self.fork_stop_button)

                self.fork_alert_output = QTextEdit()
                self.fork_alert_output.setReadOnly(True)

                layout.addWidget(QLabel("Fork Bomb Alerts:"))
                layout.addWidget(self.fork_alert_output)

                self.fork_start_button.clicked.connect(self.launch_fork_monitor)
                self.fork_stop_button.clicked.connect(self.stop_fork_monitor)

            else:
                layout.addWidget(QLabel(f"Launch {name} monitoring:"))
                launch = QPushButton("Start")
                layout.addWidget(launch)
                launch.clicked.connect(lambda: self.start_defense(name))

            dialog.setLayout(layout)
            dialog.exec_()
        return launcher
    
    def load_blocked_ips(self):
        self.blocked_list.clear()
        try:
            with open("syn_blocked_ips.txt", "r") as f:
                for line in f:
                    self.blocked_list.addItem(line.strip())
        except FileNotFoundError:
            pass

    def unblock_ip(self):
        item = self.blocked_list.currentItem()
        if item:
            ip = item.text().strip().split()[0]
            subprocess.run(["sudo", "iptables", "-D", "INPUT", "-s", ip, "-j", "DROP"])
            with open("syn_blocked_ips.txt", "r") as f:
                lines = f.readlines()
            with open("syn_blocked_ips.txt", "w") as f:
                for line in lines:
                    if line.strip() != ip:
                        f.write(line)
            self.load_blocked_ips()
            QMessageBox.information(self, "IP Unblocked", f"Unblocked IP: {ip}")

    def launch_syn_defense(self):
        args = [
            self.syn_interval.text(),
            self.syn_per_ip.text(),
            self.syn_global.text()
        ]
        self.syn_proc = subprocess.Popen(["sudo", "python3", "synDef1.py"] + args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        thread = threading.Thread(target=self.read_output, args=(self.syn_proc,), daemon=True)
        thread.start()
        self.start_button.setText("Running...")
        self.start_button.setEnabled(False)
        self.stop_button.setEnabled(True)

    def stop_syn_defense(self):
        if self.syn_proc:
            self.append_output("[INFO] Stopping SYN Defense...")
            self.syn_proc.send_signal(signal.SIGINT)
            self.syn_proc = None
        self.start_button.setText("Start SYN Defense")
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False)

    def launch_cpu_monitor(self):
        self.cpu_proc = subprocess.Popen(
            ["sudo", "python3", "-u", "cpuBurnDef.py"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=1,
            universal_newlines=True
        )
        thread = threading.Thread(target=self.read_output, args=(self.cpu_proc,), kwargs={"cpu":True}, daemon=True)
        thread.start()

        self.cpu_start_button.setText("Running...")
        self.cpu_start_button.setEnabled(False)
        self.cpu_stop_button.setEnabled(True)

    def stop_cpu_monitor(self):
        if self.cpu_proc:
            self.append_output("[INFO] Stopping CPU Monitor...")
            self.cpu_proc.send_signal(signal.SIGINT)
            self.cpu_proc = None

        self.cpu_start_button.setText("Start CPU Monitor")
        self.cpu_start_button.setEnabled(True)
        self.cpu_stop_button.setEnabled(False)

    def launch_http_monitor(self):
        args = [self.http_threshold.text(), self.http_interval.text()]
        self.http_proc = subprocess.Popen(
            ["sudo", "python3", "httpFloodDef.py"] + args,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True
        )
        thread = threading.Thread(target=self.read_output, args=(self.http_proc,), daemon=True)
        thread.start()

        self.http_start_button.setText("Running...")
        self.http_start_button.setEnabled(False)
        self.http_stop_button.setEnabled(True)

    def stop_http_monitor(self):
        if hasattr(self, 'http-proc') and self.http_proc:
            self.append_output("[INFO] Stopping HTTP Monitor...")
            self.http_proc.send_signal(signal.SIGINT)
            self.http_proc = None

        self.http_start_button.setText("Start HTTP Monitor...")
        self.http_start_button.setEnabled(True)
        self.http_stop_button.setEnabled(False)

    def load_http_blocked_ips(self):
        self.http_blocked_list.clear()
        try:
            with open("http_blocked_ips.txt", "r") as f:
                unique_ips = sorted(set(line.strip() for line in f if line.strip()))
                self.http_blocked_list.addItems(unique_ips)
        except FileNotFoundError:
            pass

    def unblock_http_ip(self):
        item = self.http_blocked_list.currentItem()
        if item:
            ip = item.text().strip().split()[0]
            subprocess.run(["sudo", "iptables", "-D", "INPUT", "-s", ip, "-j", "DROP"])
            with open("http_blocked_ips.txt", "r") as f:
                lines = f.readlines()
            with open("http_blocked_ips.txt", "w") as f:
                for line in lines:
                    if line.strip().split()[0] != ip:
                        f.write(line)
            self.load_http_blocked_ips()
            QMessageBox.information(self, "IP Unblocked", f"Unblocked IP: {ip}")

    def launch_fork_monitor(self):
        self.fork_proc = subprocess.Popen(
            ["sudo", "python3", "-u", "frkBombDef.py"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=1,
            universal_newlines=True
        )
        thread = threading.Thread(target=self.read_output, args=(self.fork_proc, True), daemon=True)
        thread.start()

        self.fork_start_button.setText("Running...")
        self.fork_start_button.setEnabled(False)
        self.fork_stop_button.setEnabled(True)

    def stop_fork_monitor(self):
        if self.fork_proc:
            self.append_output("[INFO] Stopping Fork Bomb Monitor...")
            self.fork_proc.send_signal(signal.SIGINT)
            self.fork_proc = None

        self.fork_start_button.setText("Start Fork Bomb Monitor")
        self.fork_start_button.setEnabled(True)
        self.fork_stop_button.setEnabled(False)

    def append_fork_output(self, text):
        if hasattr(self, 'fork_alert_output'):
            self.fork_alert_output.append(text)
    
    def append_cpu_output(self, text):
        if hasattr(self, 'cpu_alert_output'):
            self.cpu_alert_output.append(text)
    
    def start_defense(self, name):
        script_map = {
            "SYN Monitor": "synDef.py",
            "CPU Monitor": "cpuBurnDef.py",
            "HTTP Monitor": "httpFloodDef.py",
            "Fork Bomb Monitor": "frkBombDef.py"
        }
        script = script_map.get(name)
        if script:
            thread = threading.Thread(target=self.run_script, args=(script,), daemon=True)
            thread.start()

    def run_script(self, script, args=[]):
        self.append_output(f"[INFO] Launching {script}...")
        proc = subprocess.Popen(["sudo", "python3", script] + args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        thread = threading.Thread(target=self.read_output, args=(proc,), daemon=True)
        thread.start()

    def read_output(self, proc, fork=False, cpu=False):
        for line in proc.stdout:
            clean = line.strip()
            self.emitter.text_output.emit(clean)
            if fork:
                self.emitter.fork_output.emit(clean)
            if cpu:
                self.emitter.cpu_output.emit(clean)
            if "[!] Killed process PID" in clean:
                QTimer.singleShot(0, lambda: QMessageBox.information(self, "CPU Mitigation", clean))
    
    def append_output(self, text):
        cursor = self.output.textCursor()
        at_bottom = cursor.atEnd()

        self.output.append(text)
    
        if at_bottom:
            self.output.moveCursor(cursor.End)
            self.output.ensureCursorVisible()

    def toggle_graph(self):
        if not self.metric_window:
            self.metric_window = MetricsGraph()
        self.metric_window.show()

    def update_logs(self):
        scroll_bar = self.output.verticalScrollBar()
        at_bottom = scroll_bar.value() == scroll_bar.maximum()

        combined_logs = ""
        for log_file in LOG_FILES:
            if os.path.exists(log_file):
                with open(log_file, 'r') as f:
                    combined_logs += f"--- {log_file} ---\n" + f.read() + "\n"

        self.output.setPlainText(combined_logs)

        if at_bottom:
            scroll_bar.setValue(scroll_bar.maximum())

if __name__ == '__main__':
    app = QApplication(sys.argv)

    #load theme
    try:
        with open("defGUI_lightblue.qss", "r") as file:
            app.setStyleSheet(file.read())
    except Exception as e:
        print(f"Theme not loaded: {e}")

    window = DefenseGUI()
    window.show()
    sys.exit(app.exec_())