import subprocess
import time
import re
from collections import defaultdict
import datetime
import logging
import sys

#config
CONTAINER_NAME = "web"
THRESHOLD_REQUESTS = 100
THRESHOLD_SECONDS = 10
LOG_FILE = "httpFloodDef.log"
BLOCKED_IPS_FILE = "http_blocked_ips.txt"
BLOCKED_IPS = set()

#args
if len(sys.argv) >= 2:
    THRESHOLD_REQUESTS = int(sys.argv[1])
if len(sys.argv) >= 3:
    THRESHOLD_SECONDS = int(sys.argv[2])

#logging
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

def load_blocked_ips():
    try:
        with open(BLOCKED_IPS_FILE, "r") as f:
            for line in f:
                BLOCKED_IPS.add(line.strip())
    except FileNotFoundError:
        pass

def save_blocked_ip(ip):
    with open(BLOCKED_IPS_FILE, "a") as f:
        f.write(ip + "\n")

def block_ip(ip):
    if ip in BLOCKED_IPS:
        return
    try:
        subprocess.run(["sudo", "iptables", "-A", "INPUT", "-s", ip, "-j", "DROP"], check=True)
        BLOCKED_IPS.add(ip)
        save_blocked_ip(ip)
        logging.warning(f"Blocked IP: {ip} due to HTTP flood.")
    except Exception as e:
        logging.error(f"Failed to block IP {ip}: {e}")

# def get_nginx_access_log():
#     try:
#         result = subprocess.run(
#             ["sudo", "docker", "exec", CONTAINER_NAME, "tail", f"-n{LOG_LINES}", "/var/log/nginx/access.log"],
#             stdout=subprocess.PIPE,
#             stderr=subprocess.PIPE,
#             text=True
#         )
#         return result.stdout
#     except Exception as e:
#         logging.error(f"Failed to tail access log from container {CONTAINER_NAME}: {e}")
#         return ""

def get_docker_logs():
    try:
        result = subprocess.run(
            ["sudo", "docker", "logs", "--since", f"{THRESHOLD_SECONDS}s", CONTAINER_NAME],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        return result.stdout
    except Exception as e:
        logging.error(f"Failed to retrieve logs from container {CONTAINER_NAME}: {e}")
        return ""
    
def parse_logs_and_detect(logs):
    ip_counts = defaultdict(int)
    for line in logs.splitlines():
        match = re.match(r"^(\d+\.\d+\.\d+\.\d+)", line)
        if match:
            ip = match.group(1)
            ip_counts[ip] += 1
    return ip_counts

def main():
    load_blocked_ips()
    print(f"[+] HTTP Flood Defense Started. Monitoring container: {CONTAINER_NAME} (stdout)")
    while True:
        logs = get_docker_logs()
        ip_counts = parse_logs_and_detect(logs)

        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"[{timestamp}] Scanning logs for IP activity...")

        for ip, count in ip_counts.items():
            print(f"   {ip}: {count} requests.")
            if count >= THRESHOLD_REQUESTS:
                print(f"[!] Detected potential HTTP flood from {ip} ({count} requests)")
                logging.info(f"Detected HTTP flood from {ip} ({count} requests.)")
                block_ip(ip)

        time.sleep(THRESHOLD_SECONDS)

if __name__ == "__main__":
    main()